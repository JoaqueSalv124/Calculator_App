package com.calculatorapp


import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import net.objecthunter.exp4j.ExpressionBuilder


class MainActivity : AppCompatActivity() {

    private lateinit var inputTextView: TextView
    private lateinit var outputTextView: TextView
    private var input: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        loadData()

        bt_button.setOnClickListener {it:View!
                saveData()
        }
        inputTextView = findViewById(R.id.input)
        outputTextView = findViewById(R.id.output)


        val buttons = listOf<Button>(
            findViewById(R.id.button0),
            findViewById(R.id.button1),
            findViewById(R.id.button2),
            findViewById(R.id.button3),
            findViewById(R.id.button4),
            findViewById(R.id.button5),
            findViewById(R.id.button6),
            findViewById(R.id.button7),
            findViewById(R.id.button8),
            findViewById(R.id.button9),
            findViewById(R.id.button_dot),
            findViewById(R.id.button_add),
            findViewById(R.id.button_sub),
            findViewById(R.id.button_multi),
            findViewById(R.id.button_devide),
            findViewById(R.id.button_LeftParenthesis),
            findViewById(R.id.button_RightParenthesis),
            findViewById(R.id.button_clear),
            findViewById(R.id.button_equal),
            findViewById(R.id.button_power),
            findViewById(R.id.button_backspace),
            findViewById(R.id.button_para1),  // Button for Toggle Sign (+/-)
            findViewById(R.id.button_para2)   // Button for Percentage
        )


        buttons.forEach { button ->
            button.setOnClickListener(View.OnClickListener { v: View ->
                handleButtonClick(button.text.toString())
            })
        }
    }


    private fun appendInput(value: String) {
        if (input == "0" && value != ".") {
            input = value
        } else {
            input += value
        }
        inputTextView.text = input
    }


    private fun appendDecimal() {
        if (!input.contains(".")) {
            input += "."
            inputTextView.text = input
        }
    }


    private fun handleOperator(op: String) {
        if (input.isNotEmpty()) {
            // Allow operator if the last character is a digit, closing parenthesis, or percentage symbol
            if (input.last().isDigit() || input.last() == ')' || input.last() == '%') {
                input += " $op "
                inputTextView.text = input
            }
        }
    }


    private fun calculateResult() {
        try {
            if (input.isNotEmpty()) {
                // Prepare the expression for evaluation
                val preparedInput = input.replace("x", "*").replace("÷", "/").replace("%", "/100")


                // Build and evaluate the expression
                val expression = ExpressionBuilder(preparedInput).build()
                val result = expression.evaluate()

                val saveData = sharedPreference


                // Format the result to avoid decimal places if it's a whole number
                val formattedResult = if (result == result.toInt().toDouble()) {
                    result.toInt().toString()
                } else {
                    result.toString()
                }


                // Show result
                outputTextView.text = formattedResult
                input = formattedResult
                inputTextView.text = input
            }
        } catch (e: Exception) {
            outputTextView.text = "Error"  // In case of an invalid expression or error
        }
    }




    private fun clearInput() {
        input = ""
        inputTextView.text = ""
        outputTextView.text = ""
    }


    private fun handlePercentage() {
        if (input.isNotEmpty()) {
            // If the last character is a digit, append the percentage symbol
            if (input.last().isDigit()) {
                input += "%"
                inputTextView.text = input
            }
        }
    }




    private fun toggleSign() {
        if (input.isNotEmpty()) {
            // Check if the current number is already negative
            if (input.startsWith("(-") && input.endsWith(")")) {
                // Remove the negative wrapping
                input = input.substring(2, input.length - 1)
            } else if (input.startsWith("(")) {
                // Add negative sign inside the existing parenthesis
                input = "(-" + input.substring(1)
            } else {
                // Simply prepend a negative sign if there are no parentheses
                input = "-$input"
            }
            inputTextView.text = input
        } else {
            // Handle if the input is empty, set it to just "-"
            input = "-"
            inputTextView.text = input
        }
    }






    private fun handleButtonClick(value: String) {
        when {
            value.isNumeric() -> appendInput(value)
            value == "." -> appendDecimal()
            value in setOf("+", "-", "x", "÷", "^") -> handleOperator(value)
            value == "=" -> calculateResult()
            value == "AC" -> clearInput()
            value == "+/-" -> toggleSign()  // Toggle sign for the most recent number
            value == "⟵" -> handleBackspace()
            value == "(" || value == ")" -> handleParenthesis(value)
            value == "%" -> handlePercentage()
        }
    }


    // Helper extension function to check if a string represents a number
    private fun String.isNumeric(): Boolean {
        return try {
            this.toDouble()
            true
        } catch (e: NumberFormatException) {
            false
        }
    }


    // Handle backspace functionality
    private fun handleBackspace() {
        if (input.isNotEmpty()) {
            input = input.substring(0, input.length - 1)
            inputTextView.text = input
        }
    }

    // Handle parentheses functionality (if needed)
    private fun handleParenthesis(value: String) {
        if (value == "(") {
            input += "("
        } else if (value == ")") {
            // Allow closing parenthesis if the last character is a digit, a percentage symbol, or another closing parenthesis
            if (input.isNotEmpty() && (input.last().isDigit() || input.last() == '%' || input.last() == ')')) {
                input += ")"
            }
        }
        inputTextView.text = input
    }
}





